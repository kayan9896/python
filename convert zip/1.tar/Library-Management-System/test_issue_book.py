import unittest
import sqlite3
import os
import sys
from datetime import date, datetime, timedelta

class TestIssueBook(unittest.TestCase):
    """Test case for issuing books functionality."""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Connect to the database
        self.conn = sqlite3.connect('library_administration.db')
        self.cursor = self.conn.cursor()
        
        # Create test data
        self.test_book_id = 1
        self.test_student_id = 2
        
        # Create test book
        self.cursor.execute(
            "INSERT INTO books VALUES (?, ?, ?, ?)",
            [self.test_book_id, "Test Book", "Test Author", 1]  # Available
        )
        
        # Create test student
        self.cursor.execute(
            "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image', 'Fine', 'Books_Issued') VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ["10", "Test Student", self.test_student_id, "10A", "1234567890", b'test_image', 0, 0]
        )
        
        self.conn.commit()
        
    def tearDown(self):
        """Tear down test fixtures after each test method."""
        # Delete test records
        self.cursor.execute("DELETE FROM issue WHERE BID = ? AND SID = ?", [self.test_book_id, self.test_student_id])
        self.cursor.execute("DELETE FROM books WHERE Book_Id = ?", [self.test_book_id])
        self.cursor.execute("DELETE FROM students WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        self.cursor.close()
        self.conn.close()
    
    def test_issue_book(self):
        """Test issuing a book to a student."""
        # Issue the book
        self.cursor.execute(
            "INSERT INTO issue VALUES (?, ?, date('now'), date('now', '+15 days'))",
            [self.test_book_id, self.test_student_id]
        )
        # Update book availability
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        # Update student's books issued count
        self.cursor.execute("UPDATE students SET Books_Issued = 1 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Check if book was issued correctly
        self.cursor.execute("SELECT * FROM issue WHERE BID = ? AND SID = ?", [self.test_book_id, self.test_student_id])
        issue_record = self.cursor.fetchone()
        self.assertIsNotNone(issue_record, "Book was not issued to student")
        
        # Check book availability status
        self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
        availability = self.cursor.fetchone()[0]
        self.assertEqual(availability, 0, "Book should be unavailable after issuing")
        
        # Check student's books issued count
        self.cursor.execute("SELECT Books_Issued FROM students WHERE Student_Id = ?", [self.test_student_id])
        books_issued = self.cursor.fetchone()[0]
        self.assertEqual(books_issued, 1, "Student's books issued count is incorrect")
    
    def test_exceed_max_books(self):
        """Test that a student cannot issue more than 3 books."""
        # Set student's books issued count to 3 (maximum)
        self.cursor.execute("UPDATE students SET Books_Issued = 3 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Attempt to issue a book
        try:
            self.cursor.execute(
                "INSERT INTO issue VALUES (?, ?, date('now'), date('now', '+15 days'))",
                [self.test_book_id, self.test_student_id]
            )
            self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
            self.conn.commit()
            
            # If we get here, no exception was raised - check that no issue record exists
            self.cursor.execute("SELECT * FROM issue WHERE BID = ? AND SID = ?", [self.test_book_id, self.test_student_id])
            issue_record = self.cursor.fetchone()
            self.assertIsNone(issue_record, "Book should not be issued when student has max books")
            
            # Check book availability remains unchanged
            self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
            availability = self.cursor.fetchone()[0]
            self.assertEqual(availability, 1, "Book availability should remain unchanged")
        except Exception as e:
            # Any exception is acceptable since the system should prevent this
            pass
    
    def test_issue_book_with_fine(self):
        """Test issuing a book to a student with a fine less than 100."""
        # Add a fine to the student (below threshold)
        self.cursor.execute("UPDATE students SET Fine = 50 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Issue the book - should work with fine under 100
        self.cursor.execute(
            "INSERT INTO issue VALUES (?, ?, date('now'), date('now', '+15 days'))",
            [self.test_book_id, self.test_student_id]
        )
        # Update book availability
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        # Update student's books issued count
        self.cursor.execute("UPDATE students SET Books_Issued = 1 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Check if book was issued
        self.cursor.execute("SELECT * FROM issue WHERE BID = ? AND SID = ?", [self.test_book_id, self.test_student_id])
        issue_record = self.cursor.fetchone()
        self.assertIsNotNone(issue_record, "Book should be issued with fine under 100")
    
    def test_issue_book_with_high_fine(self):
        """Test that a student with fine >= 100 cannot issue books."""
        # Add a high fine to the student
        self.cursor.execute("UPDATE students SET Fine = 150 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Attempt to issue a book
        try:
            self.cursor.execute(
                "INSERT INTO issue VALUES (?, ?, date('now'), date('now', '+15 days'))",
                [self.test_book_id, self.test_student_id]
            )
            self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
            self.conn.commit()
            
            # If we get here, no exception was raised - check that no issue record exists
            self.cursor.execute("SELECT * FROM issue WHERE BID = ? AND SID = ?", [self.test_book_id, self.test_student_id])
            issue_record = self.cursor.fetchone()
            self.assertIsNone(issue_record, "Book should not be issued when student has fine >= 100")
            
            # Check book availability remains unchanged
            self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
            availability = self.cursor.fetchone()[0]
            self.assertEqual(availability, 1, "Book availability should remain unchanged")
        except Exception as e:
            # Any exception is acceptable since the system should prevent this
            pass

if __name__ == '__main__':
    unittest.main()
