import unittest
import sqlite3
import os
import sys

class TestSearchFunctionality(unittest.TestCase):
    """Test case for search functionality in the library system."""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Connect to the database
        self.conn = sqlite3.connect('library_administration.db')
        self.cursor = self.conn.cursor()
        
        # Create test data
        self.test_book_id = 1
        self.test_book_name = "Test Book Search"
        self.test_book_author = "Test Author"
        
        self.test_student_id = 2
        self.test_student_name = "Test Student Search"
        
        # Create test book
        self.cursor.execute(
            "INSERT INTO books VALUES (?, ?, ?, ?)",
            [self.test_book_id, self.test_book_name, self.test_book_author, 1]
        )
        
        # Create test student
        self.cursor.execute(
            "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image', 'Fine', 'Books_Issued') VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ["10", self.test_student_name, self.test_student_id, "10A", "1234567890", b'test_image', 0, 0]
        )
        
        self.conn.commit()
        
    def tearDown(self):
        """Tear down test fixtures after each test method."""
        # Delete test records
        self.cursor.execute("DELETE FROM books WHERE Book_Id = ?", [self.test_book_id])
        self.cursor.execute("DELETE FROM students WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        self.cursor.close()
        self.conn.close()
    
    def test_search_book_by_id(self):
        """Test searching for a book by ID."""
        # Search for the book by ID
        self.cursor.execute("SELECT * FROM books WHERE Book_Id = ?", [self.test_book_id])
        book = self.cursor.fetchone()
        
        # Verify search results
        self.assertIsNotNone(book, "Book should be found by ID")
        self.assertEqual(book[0], self.test_book_id, "Book ID doesn't match")
        self.assertEqual(book[1], self.test_book_name, "Book name doesn't match")
        self.assertEqual(book[2], self.test_book_author, "Book author doesn't match")
    
    def test_search_book_by_name(self):
        """Test searching for a book by name."""
        # Search for the book by name (using LIKE for partial matches)
        name_pattern = f"%{self.test_book_name[:5]}%"  # Search for first few characters
        self.cursor.execute("SELECT * FROM books WHERE Book_Name LIKE ?", [name_pattern])
        book = self.cursor.fetchone()
        
        # Verify search results
        self.assertIsNotNone(book, "Book should be found by name")
        self.assertEqual(book[1], self.test_book_name, "Book name doesn't match")
    
    def test_search_book_by_author(self):
        """Test searching for a book by author."""
        # Search for the book by author (using LIKE for partial matches)
        author_pattern = f"%{self.test_book_author[:5]}%"  # Search for first few characters
        self.cursor.execute("SELECT * FROM books WHERE Author LIKE ?", [author_pattern])
        book = self.cursor.fetchone()
        
        # Verify search results
        self.assertIsNotNone(book, "Book should be found by author")
        self.assertEqual(book[2], self.test_book_author, "Book author doesn't match")
    
    def test_search_student_by_id(self):
        """Test searching for a student by ID."""
        # Search for the student by ID
        self.cursor.execute("SELECT * FROM students WHERE Student_Id = ?", [self.test_student_id])
        student = self.cursor.fetchone()
        
        # Verify search results
        self.assertIsNotNone(student, "Student should be found by ID")
        self.assertEqual(student[2], self.test_student_id, "Student ID doesn't match")
        self.assertEqual(student[1], self.test_student_name, "Student name doesn't match")
    
    def test_search_student_by_name(self):
        """Test searching for a student by name."""
        # Search for the student by name (using LIKE for partial matches)
        name_pattern = f"%{self.test_student_name[:5]}%"  # Search for first few characters
        self.cursor.execute("SELECT * FROM students WHERE name LIKE ?", [name_pattern])
        student = self.cursor.fetchone()
        
        # Verify search results
        self.assertIsNotNone(student, "Student should be found by name")
        self.assertEqual(student[1], self.test_student_name, "Student name doesn't match")
    
    def test_search_nonexistent_book(self):
        """Test searching for a book that doesn't exist."""
        # Search for a non-existent book
        nonexistent_id = "NONEXISTENT"
        self.cursor.execute("SELECT * FROM books WHERE Book_Id = ?", [nonexistent_id])
        book = self.cursor.fetchone()
        
        # Verify no results
        self.assertIsNone(book, "No book should be found with non-existent ID")
    
    def test_search_nonexistent_student(self):
        """Test searching for a student that doesn't exist."""
        # Search for a non-existent student
        nonexistent_id = "NONEXISTENT"
        self.cursor.execute("SELECT * FROM students WHERE Student_Id = ?", [nonexistent_id])
        student = self.cursor.fetchone()
        
        # Verify no results
        self.assertIsNone(student, "No student should be found with non-existent ID")
    
    def test_search_book_availability(self):
        """Test searching for available books."""
        # Issue the book (make it unavailable)
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        self.conn.commit()
        
        # Search for available books
        self.cursor.execute("SELECT * FROM books WHERE Availiability = 1")
        available_books = self.cursor.fetchall()
        
        # Verify our test book is not in the results
        book_ids = [book[0] for book in available_books]
        self.assertNotIn(self.test_book_id, book_ids, "Unavailable book should not appear in available books search")
        
        # Return the book
        self.cursor.execute("UPDATE books SET Availiability = 1 WHERE Book_Id = ?", [self.test_book_id])
        self.conn.commit()
        
        # Search again
        self.cursor.execute("SELECT * FROM books WHERE Availiability = 1")
        available_books = self.cursor.fetchall()
        
        # Verify our test book is now in the results
        book_ids = [book[0] for book in available_books]
        self.assertIn(self.test_book_id, book_ids, "Available book should appear in available books search")

if __name__ == '__main__':
    unittest.main()
