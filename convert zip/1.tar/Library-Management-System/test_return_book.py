import unittest
import sqlite3
import os
import sys
from datetime import date, datetime, timedelta

class TestReturnBook(unittest.TestCase):
    """Test case for returning books functionality."""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Connect to the database
        self.conn = sqlite3.connect('library_administration.db')
        self.cursor = self.conn.cursor()
        
        # Create test data
        self.test_book_id = 1
        self.test_student_id = 2
        
        # Create test book
        self.cursor.execute(
            "INSERT INTO books VALUES (?, ?, ?, ?)",
            [self.test_book_id, "Test Book", "Test Author", 1]  # Available
        )
        
        # Create test student
        self.cursor.execute(
            "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image', 'Fine', 'Books_Issued') VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ["10", "Test Student", self.test_student_id, "10A", "1234567890", b'test_image', 0, 0]
        )
        
        self.conn.commit()
        
    def tearDown(self):
        """Tear down test fixtures after each test method."""
        # Delete test records
        self.cursor.execute("DELETE FROM issue WHERE BID = ? AND SID = ?", [self.test_book_id, self.test_student_id])
        self.cursor.execute("DELETE FROM books WHERE Book_Id = ?", [self.test_book_id])
        self.cursor.execute("DELETE FROM students WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        self.cursor.close()
        self.conn.close()
    
    def test_return_book_on_time(self):
        """Test returning a book on or before its due date."""
        # First issue the book
        self.cursor.execute(
            "INSERT INTO issue VALUES (?, ?, date('now'), date('now', '+15 days'))",
            [self.test_book_id, self.test_student_id]
        )
        # Update book availability
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        # Update student's books issued count
        self.cursor.execute("UPDATE students SET Books_Issued = 1 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Now return the book
        self.cursor.execute("DELETE FROM issue WHERE BID = ?", [self.test_book_id])
        self.cursor.execute("UPDATE books SET Availiability = 1 WHERE Book_Id = ?", [self.test_book_id])
        self.cursor.execute("UPDATE students SET Books_Issued = 0 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Check if book is available again
        self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
        availability = self.cursor.fetchone()[0]
        self.assertEqual(availability, 1, "Book should be available after return")
        
        # Check if issue record is removed
        self.cursor.execute("SELECT * FROM issue WHERE BID = ?", [self.test_book_id])
        issue_record = self.cursor.fetchone()
        self.assertIsNone(issue_record, "Issue record should be deleted after return")
        
        # Check student's books issued count
        self.cursor.execute("SELECT Books_Issued FROM students WHERE Student_Id = ?", [self.test_student_id])
        books_issued = self.cursor.fetchone()[0]
        self.assertEqual(books_issued, 0, "Student's books issued count should be 0 after return")
    
    def test_return_overdue_book(self):
        """Test returning an overdue book."""
        # Issue book with return date in the past
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        self.cursor.execute(
            "INSERT INTO issue VALUES (?, ?, date('now', '-20 days'), ?)",
            [self.test_book_id, self.test_student_id, yesterday]
        )
        # Update book availability
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        # Update student's books issued count
        self.cursor.execute("UPDATE students SET Books_Issued = 1 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Calculate expected fine (should be at least 1 day)
        expected_fine_days = (datetime.now() - datetime.strptime(yesterday, "%Y-%m-%d")).days
        self.cursor.execute("UPDATE students SET Fine = ? WHERE Student_Id = ?", [expected_fine_days, self.test_student_id])
        
        # Now return the book
        self.cursor.execute("DELETE FROM issue WHERE BID = ?", [self.test_book_id])
        self.cursor.execute("UPDATE books SET Availiability = 1 WHERE Book_Id = ?", [self.test_book_id])
        self.cursor.execute("UPDATE students SET Books_Issued = 0 WHERE Student_Id = ?", [self.test_student_id])
        # Fine should already be set in students table during the return process
        self.conn.commit()
        
        # Check if fine was applied (we can't calculate exact fine because of time differences)
        self.cursor.execute("SELECT Fine FROM students WHERE Student_Id = ?", [self.test_student_id])
        fine = self.cursor.fetchone()[0]
        self.assertGreaterEqual(fine, expected_fine_days, "Student should have accumulated fine for overdue period")
    
    def test_return_nonexistent_book(self):
        """Test trying to return a book that wasn't issued."""
        # Don't issue the book, just try to return it
        try:
            self.cursor.execute("DELETE FROM issue WHERE BID = ?", [self.test_book_id])
            self.cursor.execute("UPDATE books SET Availiability = 1 WHERE Book_Id = ?", [self.test_book_id])
            self.cursor.execute("UPDATE students SET Books_Issued = 0 WHERE Student_Id = ?", [self.test_student_id])
            self.conn.commit()
            
            # If no exception, check that the book became available (this is system-dependent behavior)
            self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
            availability = self.cursor.fetchone()[0]
            
            # This could be 1 if the system allows returning without checking
            # or it could stay 1 if the logic prevents the update - both are acceptable
            # We just verify that nothing broke
            self.assertIn(availability, [0, 1], "Book availability should be valid after return attempt")
            
        except Exception:
            # Exception is acceptable - test passes
            pass
    
    def test_return_book_with_high_fine(self):
        """Test returning a book when student has high fine."""
        # First set high fine for student
        self.cursor.execute("UPDATE students SET Fine = 150 WHERE Student_Id = ?", [self.test_student_id])
        
        # Issue the book
        self.cursor.execute(
            "INSERT INTO issue VALUES (?, ?, date('now'), date('now', '+15 days'))",
            [self.test_book_id, self.test_student_id]
        )
        # Update book availability
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        # Update student's books issued count
        self.cursor.execute("UPDATE students SET Books_Issued = 1 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Now return the book
        self.cursor.execute("DELETE FROM issue WHERE BID = ?", [self.test_book_id])
        self.cursor.execute("UPDATE books SET Availiability = 1 WHERE Book_Id = ?", [self.test_book_id])
        self.cursor.execute("UPDATE students SET Books_Issued = 0 WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        
        # Check if book is available again
        self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
        availability = self.cursor.fetchone()[0]
        self.assertEqual(availability, 1, "Book should be available after return")
        
        # Check if student's fine is still high after return (library policy may vary)
        self.cursor.execute("SELECT Fine FROM students WHERE Student_Id = ?", [self.test_student_id])
        fine = self.cursor.fetchone()[0]
        # The fine may be reduced or remain high depending on system policy
        # We just verify it hasn't increased
        self.assertLessEqual(fine, 150, "Fine should not increase after return")

if __name__ == '__main__':
    unittest.main()
