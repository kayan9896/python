import unittest
import sqlite3
import os
import sys

class TestAddBooks(unittest.TestCase):
    """Test case for adding books functionality."""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Connect to the database
        self.conn = sqlite3.connect('library_administration.db')
        self.cursor = self.conn.cursor()
        # Create a test book record to use in tests
        self.test_book_id = 1
        self.test_book_data = {
            'Book_Id': self.test_book_id,
            'Book_Name': 'Test Book',
            'Book_Author': 'Test Author',
            'Availiability': 1  # Available (1) or not (0)
        }
        
    def tearDown(self):
        """Tear down test fixtures after each test method."""
        # Delete any test records created
        self.cursor.execute("DELETE FROM books WHERE Book_Id = ?", [self.test_book_id])
        self.conn.commit()
        self.cursor.close()
        self.conn.close()
    
    def test_add_book(self):
        """Test adding a new book to the database."""
        # Add book to database
        self.cursor.execute(
            "INSERT INTO books VALUES (?, ?, ?, ?)",
            [
                self.test_book_data['Book_Id'],
                self.test_book_data['Book_Name'],
                self.test_book_data['Book_Author'],
                self.test_book_data['Availiability']
            ]
        )
        self.conn.commit()
        
        # Retrieve the book we just added
        self.cursor.execute("SELECT * FROM books WHERE Book_Id = ?", [self.test_book_id])
        book = self.cursor.fetchone()
        
        # Check if book was added successfully
        self.assertIsNotNone(book, "Book was not added to the database")
        self.assertEqual(book[0], self.test_book_id, "Book ID doesn't match")
        self.assertEqual(book[1], self.test_book_data['Book_Name'], "Book name doesn't match")
        self.assertEqual(book[2], self.test_book_data['Book_Author'], "Book author doesn't match")
        self.assertEqual(book[3], self.test_book_data['Availiability'], "Book availability doesn't match")
    
    def test_duplicate_book_id(self):
        """Test adding a book with duplicate ID."""
        # First add the book
        self.cursor.execute(
            "INSERT INTO books VALUES (?, ?, ?, ?)",
            [
                self.test_book_data['Book_Id'],
                self.test_book_data['Book_Name'],
                self.test_book_data['Book_Author'],
                self.test_book_data['Availiability']
            ]
        )
        self.conn.commit()
        
        # Try to add the same book again
        with self.assertRaises(sqlite3.IntegrityError):
            self.cursor.execute(
                "INSERT INTO books VALUES (?, ?, ?, ?)",
                [
                    self.test_book_data['Book_Id'],     # Same ID
                    'Different Book Name',
                    'Different Author',
                    1
                ]
            )
            self.conn.commit()

    def test_book_availability(self):
        """Test book availability changes."""
        # Add book
        self.cursor.execute(
            "INSERT INTO books VALUES (?, ?, ?, ?)",
            [
                self.test_book_data['Book_Id'],
                self.test_book_data['Book_Name'],
                self.test_book_data['Book_Author'],
                self.test_book_data['Availiability']  # 1 for available
            ]
        )
        self.conn.commit()
        
        # Check initial availability
        self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
        availability = self.cursor.fetchone()[0]
        self.assertEqual(availability, 1, "Book should be available initially")
        
        # Update availability (issue the book)
        self.cursor.execute("UPDATE books SET Availiability = 0 WHERE Book_Id = ?", [self.test_book_id])
        self.conn.commit()
        
        # Check updated availability
        self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
        availability = self.cursor.fetchone()[0]
        self.assertEqual(availability, 0, "Book should be unavailable after issuing")
        
        # Return the book
        self.cursor.execute("UPDATE books SET Availiability = 1 WHERE Book_Id = ?", [self.test_book_id])
        self.conn.commit()
        
        # Check final availability
        self.cursor.execute("SELECT Availiability FROM books WHERE Book_Id = ?", [self.test_book_id])
        availability = self.cursor.fetchone()[0]
        self.assertEqual(availability, 1, "Book should be available after returning")

if __name__ == '__main__':
    unittest.main()
