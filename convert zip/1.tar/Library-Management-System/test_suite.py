import unittest
import sys

# Import all test cases
from test_add_student import TestAddStudent
from test_add_books import TestAddBooks
from test_issue_book import TestIssueBook
from test_renew_book import TestRenewBook
from test_return_book import TestReturnBook
from test_search_functionality import TestSearchFunctionality

# Create test suite
def create_test_suite():
    """Create and return a test suite containing all tests."""
    test_suite = unittest.TestSuite()
    
    # Add tests from TestAddStudent
    test_suite.addTest(unittest.makeSuite(TestAddStudent))
    
    # Add tests from TestAddBooks
    test_suite.addTest(unittest.makeSuite(TestAddBooks))
    
    # Add tests from TestIssueBook
    test_suite.addTest(unittest.makeSuite(TestIssueBook))
    
    # Add tests from TestRenewBook
    test_suite.addTest(unittest.makeSuite(TestRenewBook))
    
    # Add tests from TestReturnBook
    test_suite.addTest(unittest.makeSuite(TestReturnBook))
    
    # Add tests from TestSearchFunctionality
    test_suite.addTest(unittest.makeSuite(TestSearchFunctionality))
    
    return test_suite

if __name__ == '__main__':
    # Create test suite
    suite = create_test_suite()
    
    # Run tests and store results
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Set exit code based on test results
    sys.exit(not result.wasSuccessful())
