import unittest
import sqlite3
import os
import sys
from datetime import date

class TestAddStudent(unittest.TestCase):
    """Test case for adding students functionality."""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Connect to the database
        self.conn = sqlite3.connect('library_administration.db')
        self.cursor = self.conn.cursor()
        # Create a test student record to use in tests
        self.test_student_id = "TEST001"
        self.test_student_data = {
            'Roll_no': 10,
            'name': 'Test Student',
            'Student_Id': self.test_student_id,
            'class': '10A',
            'Phone_number': 1234567890,
            'Image': b'test_image_data'  # Mock binary data for test
        }
        
    def tearDown(self):
        """Tear down test fixtures after each test method."""
        # Delete any test records created
        self.cursor.execute("DELETE FROM students WHERE Student_Id = ?", [self.test_student_id])
        self.conn.commit()
        self.cursor.close()
        self.conn.close()
    
    def test_add_student(self):
        """Test adding a new student to the database."""
        # Add student to database
        self.cursor.execute(
            "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image') VALUES (?, ?, ?, ?, ?, ?)",
            [
                self.test_student_data['Roll_no'],
                self.test_student_data['name'],
                self.test_student_data['Student_Id'],
                self.test_student_data['class'],
                self.test_student_data['Phone_number'],
                self.test_student_data['Image']
            ]
        )
        self.conn.commit()
        
        # Retrieve the student we just added
        self.cursor.execute("SELECT * FROM students WHERE Student_Id = ?", [self.test_student_id])
        student = self.cursor.fetchone()
        
        # Check if student was added successfully
        self.assertIsNotNone(student, "Student was not added to the database")
        self.assertEqual(student[2], self.test_student_id, "Student ID doesn't match")
        self.assertEqual(student[1], self.test_student_data['name'], "Student name doesn't match")
    
    def test_duplicate_student_id(self):
        """Test adding a student with duplicate ID."""
        # First add the student
        self.cursor.execute(
            "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image') VALUES (?, ?, ?, ?, ?, ?)",
            [
                self.test_student_data['Roll_no'],
                self.test_student_data['name'],
                self.test_student_data['Student_Id'],
                self.test_student_data['class'],
                self.test_student_data['Phone_number'],
                self.test_student_data['Image']
            ]
        )
        self.conn.commit()
        
        # Try to add the same student again
        with self.assertRaises(sqlite3.IntegrityError):
            self.cursor.execute(
                "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image') VALUES (?, ?, ?, ?, ?, ?)",
                [
                    self.test_student_data['Roll_no'] + 1,  # Different roll number
                    self.test_student_data['name'],
                    self.test_student_data['Student_Id'],     # Same ID
                    self.test_student_data['class'],
                    self.test_student_data['Phone_number'] + 1,  # Different phone
                    self.test_student_data['Image']
                ]
            )
            self.conn.commit()

    def test_student_attributes(self):
        """Test all attributes of a student after adding."""
        # Add student
        self.cursor.execute(
            "INSERT INTO students ('Roll_no', 'name', 'Student_Id', 'class', 'Phone_number', 'Image', 'Fine', 'Books_Issued') VALUES (?, ?, ?, ?, ?, ?, 0, 0)",
            [
                self.test_student_data['Roll_no'],
                self.test_student_data['name'],
                self.test_student_data['Student_Id'],
                self.test_student_data['class'],
                self.test_student_data['Phone_number'],
                self.test_student_data['Image']
            ]
        )
        self.conn.commit()
        
        # Retrieve and check student
        self.cursor.execute("SELECT * FROM students WHERE Student_Id = ?", [self.test_student_id])
        student = self.cursor.fetchone()
        
        self.assertEqual(student[0], self.test_student_data['Roll_no'], "Roll number doesn't match")
        self.assertEqual(student[1], self.test_student_data['name'], "Name doesn't match")
        self.assertEqual(student[2], self.test_student_data['Student_Id'], "Student ID doesn't match")
        self.assertEqual(student[3], self.test_student_data['class'], "Class doesn't match")
        self.assertEqual(student[4], self.test_student_data['Phone_number'], "Phone number doesn't match")
        # Note: Image is binary data so we're not directly comparing it

if __name__ == '__main__':
    unittest.main()
